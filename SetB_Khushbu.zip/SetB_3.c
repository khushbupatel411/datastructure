#include <stdio.h>
#include <stdlib.h>

#define CHAR_BITS  2  // size of character

#define INT_BITS  ( sizeof(int) * CHAR_BITS)


//print data in binary
void PrintInBinary(unsigned n)
{
	short int iPos;
	
	for (iPos = (INT_BITS -1) ; iPos >= 0 ; iPos--)
	{
	  (n & (1 << iPos))? printf("1"): printf("0");	
	}
		
		

}


//bit reversal function
unsigned int ReverseTheBits(unsigned int num)
{
    unsigned int iLoop = 0;
    unsigned int tmp = 0;         //  Assign num to the tmp 
    int iNumberLopp = (INT_BITS - 1);
	     
  
    for(; iLoop < iNumberLopp; iLoop++)
    {
	      
       tmp |= num & 1; // putting the set bits of num
       
       num >>= 1; //shift the tmp Right side 
       
       tmp <<= 1;  //shift the tmp left side 
       
    }
    
    
    return tmp;
}
 
int main()
{
    unsigned int data = 0;
    unsigned int Ret = 0;
    
    printf("Enter the number : ");
    scanf("%u",&data);
    
    printf("\n\nBefore :=" );
    PrintInBinary(data);
    
    
    Ret = ReverseTheBits(data);

    printf("\n\nAfter :=" );
    PrintInBinary(Ret);
    
return 0;
}
